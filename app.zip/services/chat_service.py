from rag import Retriever
from llm.hf_model import HuggingFaceLLM
from llm.prompt_builder import PromptBuilder

class ChatService:
    def __init__(self):
        self.retriever = Retriever()
        self.prompt = PromptBuilder()
        self.llm = HuggingFaceLLM()

    def ask(self, question):
        results = self.retriever.search(question)
        chunks = results["documents"][0]
        prompt = self.prompt.build(question, chunks,)

        answer = self.llm.generate(prompt)

        return answer, results