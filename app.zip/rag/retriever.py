import chromadb

from sentence_transformers import SentenceTransformer


class Retriever:

    def __init__(self):

        self.model = SentenceTransformer(
            "all-MiniLM-L6-v2"
        )

        self.client = chromadb.PersistentClient(
            path="./data/chroma_db"
        )

        self.collection = self.client.get_collection(
            "msentinel_documents"
        )

    def search(self, query: str, top_k: int = 5):

        embedding = self.model.encode(query).tolist()

        results = self.collection.query(
            query_embeddings=[embedding],
            n_results=top_k,
        )

        return results