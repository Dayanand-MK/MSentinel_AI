from transformers import pipeline

class HuggingFaceLLM:
    def __init__(self):
        self.generator = pipeline(task = "text2text-generation", model = "google/flan-t5-base",)

    def generate(self, prompt : str):
        result = self.generator(prompt, max_new_tokens = 256, temprature = 0.2,)

        return result[0]['generated_text']